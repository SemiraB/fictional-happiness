package cucumberTest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class) 
@CucumberOptions(features="Feature", // starts at project root (in this case is "Cucumber" project) 
glue= {"stepDef"},
dryRun=true
//monochrome=true,
//format = {"pretty", "html:reports",
//		"json:reports/cucumber.json",
//		"json:reports/cucumber.xml"},
//strict=true,
//tags= {"@Shopping", "~@Logout"} // or
// tags= {"@Login", "@Logout"} -> an AND
// tags= {"@Shopping"}, {"~@Logout"} -> ~means no running
		) 
// starts at "src" directory
public class TestRunner {

}
