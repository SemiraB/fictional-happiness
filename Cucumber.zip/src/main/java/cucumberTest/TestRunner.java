package cucumberTest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class) 
@CucumberOptions(features="Feature", // starts at project root (in this case is "Cucumber" project) 
glue= {"stepDef"}) // starts at "src" directory
public class TestRunner {

}
