package stepDef;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_Steps {
	static WebDriver driver;
	@Given("^User is on Home Page$")
	public void User_is_on_Home_Page() throws Throwable {
		driver = new HtmlUnitDriver();
	    // Express the Regexp above with the code you wish you had
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://www.store.demoqa.com");
		driver.findElement(By.xpath(".//*[@id='account']/a")).click();
		driver.findElement(By.id("log")).sendKeys("1_user");
		driver.findElement(By.id("pwd")).sendKeys("@_P4wd");	 
        
        driver.findElement(By.id("login")).click();
        
	    
	}

	@When("^User Navigate to LogIn Page$")
	public void User_Navigate_to_LogIn_Page() throws Throwable {
	    // Express the Regexp above with the code you wish you had
		driver.findElement(By.xpath(".//*[@id='account_logout']/a")).click();

	}

	@When("^User enters UserName and Password$")
	public void User_enters_UserName_and_Password() throws Throwable {
	    // Express the Regexp above with the code you wish you had
		driver.findElement(By.id("log")).sendKeys("1_user");
		driver.findElement(By.id("pwd")).sendKeys("@_P4wd");
		driver.findElement(By.id("login")).click();

	}

	@Then("^Message displayed Login Successfully$")
	public void Message_displayed_Login_Successfully() throws Throwable {
	    // Express the Regexp above with the code you wish you had
		System.out.println("Login Successfully");

	}

	@When("^User LogOut from the Application$")
	public void User_LogOut_from_the_Application() throws Throwable {
	    // Express the Regexp above with the code you wish you had
	//	driver.findElement(By.xpath(".//*[@id='wp-admin-bar-logout']/a")).click();
	    
		driver.findElement (By.xpath(".//*[@id='account_logout']/a")).click();
		 
        // Print a Log In message to the screen
 
      //  System.out.println("LogOut Successfully");
		//throw new PendingException();
	}

	@Then("^Message displayed LogOut Successfully$")
	public void Message_displayed_LogOut_Successfully() throws Throwable {
	    // Express the Regexp above with the code you wish you had
		System.out.println("LogOut Successfully");
	    
	}



	//public static void main(String[] args) {
		// TODO Auto-generated method stub

	//}

}
